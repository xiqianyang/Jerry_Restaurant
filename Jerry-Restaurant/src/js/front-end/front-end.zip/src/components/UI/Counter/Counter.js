import React, {useContext} from 'react';
import classes from './Counter.module.css';
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faPlus, faMinus} from "@fortawesome/free-solid-svg-icons";
import CartContext from "../../../store/cart-context";

// Components of the counter
const Counter = (props) => {

    // getcartContext
    const ctx = useContext(CartContext);


    // add cart function
    const addButtonHandler = () => {
        ctx.addItem(props.Offer);
    };

    // function of delete food
    const subButtonHandler = () => {
        ctx.removeItem(props.Offer);
    };

    return (    
        <div className={classes.Counter}> 
        {
            (props.Offer.amount && props.Offer.amount !== 0 ) ?
            (
            <>
            <button onClick={subButtonHandler} className={classes.Sub}><FontAwesomeIcon icon={faMinus}/></button>
             <span className={classes.count}>{props.Offer.amount}</span>
             </>
            ) : null
        }
        
       
        <button 
        onClick={addButtonHandler}
        className={classes.Add}>
             <FontAwesomeIcon icon={faPlus}/></button>
        </div>
    );
};

export default Counter;
