import React from 'react';
// import { Link } from 'react-router-dom';
import classes from "./footer.module.css";

function Footer() {

  return (
    <>
    <div className={classes.icon}>
      <div >
        <p className={classes.icon}>aaa</p>
      </div>
      <div >
        <p className={classes.icon}>aaa</p>
      </div>
      <div >
        <p className={classes.icon}>aaa</p>
      </div>
      </div>
     </>
  )
}
export default Footer;