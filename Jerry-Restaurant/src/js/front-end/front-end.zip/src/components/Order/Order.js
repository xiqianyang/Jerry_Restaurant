import React ,{useContext}from 'react';
import style from './Order.module.css';
import  ReactDOM  from 'react';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// import { faXmark } from '@fortawesome/free-solid-svg-icons';

const OrderRoot = document.getElementById('Order-root');

const Order = (props) => {

    // const ctx = useContext(CartContext);

    return ReactDOM.createPortal(
    <div className={style.Checkout}>
    <div className={style.Close}>
        {/* <FontAwesomeIcon
            onClick={() => props.onHide() }
            icon={faXmark}/> */}
    </div>

    <div className={style.MealsDesc}>
        <header className={style.Header}>
            <h2 className={style.Title}>Details of Food</h2>
        </header>

        <div className={style.Meals}>
            {/* {ctx.items.map(item => <CheckoutItem key={item.id} meal={item}/>)} */}
        </div>

        <footer className={style.Footer}>
            {/* <p className={style.TotalPrice}>{ctx.totalPrice}</p> */}
            <p>123</p>
        </footer>
    </div>

    {/* <Bar totalPrice={ctx.totalPrice}/> */}

       </div>,
OrderRoot);
};

export default Order;
