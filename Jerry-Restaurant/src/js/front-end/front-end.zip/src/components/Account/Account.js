import React from 'react';
import "./Account.module.css";

export default function Account() {
  return (
    <div>Account</div>
  )
}
