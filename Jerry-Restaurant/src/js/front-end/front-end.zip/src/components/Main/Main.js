// import "./Main.module.css";
import Footer from "../footer/footer";
import Cart from "../Cart/Cart";

import React from 'react'

export default function Main() {
  return (
    <>
     <Footer/>
     <Cart/>
     </>
  )
}
